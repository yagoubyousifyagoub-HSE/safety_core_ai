/// Roles enforced both client-side (UI gating) and server-side (Supabase RLS
/// policies in supabase/schema.sql). Never trust the client-side check alone
/// for anything that mutates data — RLS is the real gate.
enum UserRole { consultant, contractor, admin }

extension UserRoleX on UserRole {
  static UserRole fromString(String? value) {
    switch (value) {
      case 'consultant':
        return UserRole.consultant;
      case 'admin':
        return UserRole.admin;
      case 'contractor':
      default:
        return UserRole.contractor;
    }
  }

  String get asString => switch (this) {
        UserRole.consultant => 'consultant',
        UserRole.contractor => 'contractor',
        UserRole.admin => 'admin',
      };

  /// Consultants are the only role permitted to sign off / close observations.
  bool get canSignOff => this == UserRole.consultant || this == UserRole.admin;

  /// Contractors submit "after" remediation evidence; consultants can too.
  bool get canSubmitCorrectiveAction => true;
}
