import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/models/user_role.dart';

class AppProfile {
  final String id;
  final String fullName;
  final UserRole role;
  final String? company;

  AppProfile({required this.id, required this.fullName, required this.role, this.company});

  factory AppProfile.fromRow(Map<String, dynamic> row) => AppProfile(
        id: row['id'] as String,
        fullName: row['full_name'] as String? ?? '',
        role: UserRoleX.fromString(row['role'] as String?),
        company: row['company'] as String?,
      );
}

/// Wraps Supabase email/password auth and resolves the caller's role from
/// `public.profiles`, which is the source of truth enforced by RLS — the
/// role returned here is for UI gating only, never a security boundary.
class AuthService {
  final SupabaseClient _client = Supabase.instance.client;

  Stream<AuthState> get onAuthStateChange => _client.auth.onAuthStateChange;

  User? get currentUser => _client.auth.currentUser;
  bool get isSignedIn => currentUser != null;

  Future<void> signInWithEmail({required String email, required String password}) async {
    await _client.auth.signInWithPassword(email: email, password: password);
  }

  Future<void> signOut() => _client.auth.signOut();

  Future<AppProfile> fetchCurrentProfile() async {
    final uid = currentUser?.id;
    if (uid == null) {
      throw StateError('AuthService.fetchCurrentProfile called with no signed-in user.');
    }
    final row = await _client.from('profiles').select().eq('id', uid).single();
    return AppProfile.fromRow(row);
  }
}
